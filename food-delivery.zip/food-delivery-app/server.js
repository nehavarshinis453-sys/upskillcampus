const express = require('express');

const cors = require('cors');

const app = express();

app.use(cors());


// ================= RESTAURANTS API =================
app.get('/restaurants', (req, res) => {

    res.json([

        {
            name: "Pizza Place",
            price: 200
        },

        {
            name: "Biryani House",
            price: 250
        },

        {
            name: "Shawarma King",
            price: 170
        },

        {
            name: "Pasta Point",
            price: 220
        },

        {
            name: "Cake Bakery",
            price: 300
        }

    ]);
});


// ================= START SERVER =================
app.listen(3000, () => {

    console.log(
        'Server running on http://127.0.0.1:3000'
    );
});