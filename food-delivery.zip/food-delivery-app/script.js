// ================= LOGIN =================
function login() {

    const user = document.getElementById("username").value;
    const pass = document.getElementById("password").value;

    if (user === "" || pass === "") {
        alert("Please enter username and password ❗");
        return;
    }

    alert("Login Successful ✅");

    localStorage.setItem("user", user);

    window.location.href = "restaurants.html";
}


// ================= PAGE LOAD =================
window.onload = function () {

    const user = localStorage.getItem("user");

    // Welcome user
    if (user && document.getElementById("welcomeUser")) {

        document.getElementById("welcomeUser").innerText =
            "Welcome, " + user + " 👋";
    }

    // Load restaurants
    if (document.getElementById("restaurantList")) {
        loadRestaurants();
    }

    // Load cart
    if (document.getElementById("cartItems")) {
        loadCart();
    }

    // Load orders
    if (document.getElementById("orderHistory")) {
        loadOrders();
    }

    // Load favorites
    if (document.getElementById("favoriteList")) {
        loadFavorites();
    }

    // Load menu
    if (document.getElementById("menuList")) {
        loadMenu();
    }
};


// ================= LOAD RESTAURANTS =================
function loadRestaurants() {

    fetch('http://localhost:3000/restaurants')
        .then(res => res.json())
        .then(data => {

            const list = document.getElementById("restaurantList");

            list.innerHTML = "";

            data.forEach(r => {

                const div = document.createElement("div");

                div.classList.add("card");

                div.innerHTML = `
                    <img 
                        src="${getImage(r.name)}"
                        style="
                            width:100%;
                            height:150px;
                            object-fit:cover;
                            border-radius:10px;
                        "
                    >

                    <h3>${r.name}</h3>

                    <p>${getItems(r.name)}</p>

                    <p>⭐ ${getRating(r.name)} Rating</p>

                    <p>Price: ₹${r.price}</p>

                    <button onclick="order('${r.name}')">
                        Order 🛒
                    </button>

                    <button onclick="addFavorite('${r.name}')">
                        ❤️ Favorite
                    </button>
                `;

                list.appendChild(div);
            });
        });
}


// ================= HELPER FUNCTIONS =================
function getImage(name) {

    if (name === "Pizza Place")
        return "./images/pizza.jpg";

    if (name === "Biryani House")
        return "./images/biryani.jpg";

    if (name === "Shawarma King")
    return "./images/shawarma.jpg";

    if (name === "Pasta Point")
    return "./images/pasta.jpg";

    if (name === "Cake Bakery")
    return "./images/cake.jpg";
}


function getItems(name) {

    if (name === "Pizza Place")
        return "Pizza, Burger";

    if (name === "Biryani House")
        return "Biryani, Chicken";

    if (name === "Shawarma King")
    return "Shawarma, Rolls";

     if (name === "Pasta Point")
    return "Pasta, Garlic Bread";

    if (name === "Cake Bakery")
    return "Cake, Desserts";
}


function getRating(name) {

    if (name === "Pizza Place")
        return "4.5";

    if (name === "Biryani House")
        return "4.7";

    if (name === "Shawarma King")
    return "4.5";

     if (name === "Pasta Point")
    return "4.4";

    if (name === "Cake Bakery")
    return "4.8";
}


// ================= ADD TO CART =================
function order(name) {

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    cart.push(name);

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    alert(name + " added to cart 🛒");
}


// ================= VIEW CART =================
function viewCart() {

    window.location.href = "cart.html";
}


// ================= LOAD CART =================
function loadCart() {

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    const container =
        document.getElementById("cartItems");

    const total =
        document.getElementById("totalPrice");

    container.innerHTML = "";

    let price = 0;

    cart.forEach((item, index) => {

        const div = document.createElement("div");

        div.classList.add("card");

        const itemPrice =
            item === "Pizza Place" ? 200 :
            item === "Biryani House" ? 250 :
            item === "Shawarma King" ? 170 :
            item === "Pasta Point" ? 220 :
            item === "Cake Bakery" ? 300 : 0;

        price += itemPrice;

        div.innerHTML = `
            <h3>${item}</h3>

            <p>Price: ₹${itemPrice}</p>

            <button onclick="removeItem(${index})">
                Remove ❌
            </button>
        `;

        container.appendChild(div);
    });

    total.innerText = "Total: ₹" + price;
}


// ================= REMOVE ITEM =================
function removeItem(index) {

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    cart.splice(index, 1);

    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );

    loadCart();
}


// ================= PAYMENT =================
function goToPayment() {

    window.location.href = "payment.html";
}


function payNow() {

    const card =
        document.getElementById("cardNumber").value;

    const expiry =
        document.getElementById("expiry").value;

    const cvv =
        document.getElementById("cvv").value;

    if (card === "" || expiry === "" || cvv === "") {

        alert("Please fill all payment details ❗");

        return;
    }

    let orders =
        JSON.parse(localStorage.getItem("orders")) || [];

    let cart =
        JSON.parse(localStorage.getItem("cart")) || [];

    orders.push({
        items: cart,
        date: new Date().toLocaleString()
    });

    localStorage.setItem(
        "orders",
        JSON.stringify(orders)
    );

    alert("Payment Successful 🎉");

    localStorage.removeItem("cart");

    window.location.href = "orders.html";
}


// ================= LOAD ORDERS =================
function loadOrders() {

    let orders =
        JSON.parse(localStorage.getItem("orders")) || [];

    const container =
        document.getElementById("orderHistory");

    container.innerHTML = "";

    orders.forEach(order => {

        const div = document.createElement("div");

        div.classList.add("card");

        div.innerHTML = `
            <h3>📦 Order</h3>

            <p>${order.items.join(", ")}</p>

            <p>🕒 ${order.date}</p>

            <a href="tracking.html">
                <button>
                    Track Order 🚚
                </button>
            </a>
        `;

        container.appendChild(div);
    });
}


// ================= SEARCH =================
function searchRestaurant() {

    const input =
        document.getElementById("searchInput")
        .value
        .toLowerCase();

    const cards =
        document.querySelectorAll(".card");

    cards.forEach(card => {

        const name =
            card.querySelector("h3")
            .innerText
            .toLowerCase();

        if (name.includes(input)) {

            card.style.display = "block";

        } else {

            card.style.display = "none";
        }
    });
}


// ================= TRACKING =================
let trackingStep = 0;

function nextStatus() {

    const status =
        document.getElementById("status");

    const eta =
        document.getElementById("eta");

    trackingStep++;

    if (trackingStep === 1) {

        status.innerText =
            "Out for Delivery 🚚";

        eta.innerText =
            "ETA: 10 mins";
    }

    else if (trackingStep === 2) {

        status.innerText =
            "Delivered ✅";

        eta.innerText =
            "ETA: Arrived";
    }
}


// ================= RESTAURANT DASHBOARD =================
function addFood() {

    const food =
        document.getElementById("foodName").value;

    const price =
        document.getElementById("foodPrice").value;

    const menu =
        JSON.parse(localStorage.getItem("menu")) || [];

    menu.push({
        food,
        price
    });

    localStorage.setItem(
        "menu",
        JSON.stringify(menu)
    );

    loadMenu();
}


function loadMenu() {

    const menu =
        JSON.parse(localStorage.getItem("menu")) || [];

    const list =
        document.getElementById("menuList");

    if (!list) return;

    list.innerHTML = "";

    menu.forEach(item => {

        const div =
            document.createElement("div");

        div.classList.add("card");

        div.innerHTML = `
            <h3>${item.food}</h3>

            <p>₹${item.price}</p>
        `;

        list.appendChild(div);
    });
}


// ================= DELIVERY =================
function pickupOrder() {

    alert("Order Picked Up 🚚");
}


function deliverOrder() {

    alert("Order Delivered ✅");
}


// ================= FAVORITES =================
function addFavorite(name) {

    let favorites =
        JSON.parse(localStorage.getItem("favorites")) || [];

    favorites.push(name);

    localStorage.setItem(
        "favorites",
        JSON.stringify(favorites)
    );

    alert("Added to Favorites ❤️");
}


function loadFavorites() {

    const favorites =
        JSON.parse(localStorage.getItem("favorites")) || [];

    const list =
        document.getElementById("favoriteList");

    if (!list) return;

    list.innerHTML = "";

    favorites.forEach(item => {

        const div =
            document.createElement("div");

        div.classList.add("card");

        div.innerHTML = `
            <h3>${item}</h3>
        `;

        list.appendChild(div);
    });
}